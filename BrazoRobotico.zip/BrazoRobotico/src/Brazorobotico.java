import com.sun.j3d.loaders.IncorrectFormatException;
import com.sun.j3d.loaders.ParsingErrorException;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.loaders.objectfile.ObjectFile;

import javax.media.j3d.*;
import javax.swing.*;
import javax.vecmath.*;
import java.awt.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class Brazorobotico extends JFrame {
    private final Map<String, TransformController> controllers = new HashMap<>();

    public Brazorobotico() {
        setTitle("Brazo Robótico");
        setSize(1200, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        Canvas3D canvas = new Canvas3D(SimpleUniverse.getPreferredConfiguration());
        mainPanel.add(canvas, BorderLayout.CENTER);
        add(mainPanel);

        SimpleUniverse universe = new SimpleUniverse(canvas);
        BranchGroup scene = createSceneGraph();
        universe.getViewingPlatform().setNominalViewingTransform();
        universe.addBranchGraph(scene);

        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
        
        // Controles específicos para cada parte
        addBaseControls(controlPanel);
        addArmControls("Brazo1", controlPanel);
        addArmControls("Brazo2", controlPanel);
        addArmControls("Brazo3", controlPanel);
        addGripperControls(controlPanel);

        JScrollPane scrollPane = new JScrollPane(controlPanel);
        scrollPane.setPreferredSize(new Dimension(300, 0));
        mainPanel.add(scrollPane, BorderLayout.EAST);
    }

    private BranchGroup createSceneGraph() {
        BranchGroup root = new BranchGroup();
        BoundingSphere bounds = new BoundingSphere(new Point3d(), 100.0);

        // Iluminación y fondo
        DirectionalLight light = new DirectionalLight(new Color3f(1f, 1f, 1f), new Vector3f(-1f, -1f, -1f));
        light.setInfluencingBounds(bounds);
        root.addChild(light);

        Background background = new Background(new Color3f(0.1f, 0.1f, 0.1f));
        background.setApplicationBounds(bounds);
        root.addChild(background);
           //142 298 3 20 -25 
        // Jerarquía de transformaciones
        TransformGroup tgBase = createPiece("Base", new Vector3f(0f, -0.5f, 0f), new Vector3f(0f, 0.0f, 0f), "models/Base.obj");
        TransformGroup tgBrazo1 = createPiece("Brazo1", new Vector3f(0f, 0.142f, 0f), new Vector3f(0f, 0.148f, 0f), "models/brazo 1.obj");
        TransformGroup tgBrazo2 = createPiece("Brazo2", new Vector3f(0f, 0.298f, 0f), new Vector3f(0f, 0.15f, 0f), "models/brazo 2.obj");
        TransformGroup tgBrazo3 = createPiece("Brazo3", new Vector3f(0f, 0.3f, 0f), new Vector3f(0f, 0.1165f, 0f), "models/Brazo3.obj");
        TransformGroup tgGarra1 = createPiece("Garra1", new Vector3f(0f, 0.24f, 0f), new Vector3f(0f, -0.0475f, -0.14f), "models/Garra1.obj");
        TransformGroup tgGarra2 = createPiece("Garra2", new Vector3f(0f, 0.24f, 0f), new Vector3f(0f, 0.0475f, -0.14f), "models/Garra2.obj");

        // Ensamblar jerarquía
        tgBrazo3.addChild(tgGarra1);
        tgBrazo3.addChild(tgGarra2);
        tgBrazo2.addChild(tgBrazo3);
        tgBrazo1.addChild(tgBrazo2);
        tgBase.addChild(tgBrazo1);
        root.addChild(tgBase);

        return root;
    }
    private TransformGroup createPiece(String name, Vector3f translation, Vector3f centro, String modelPath) {
        Transform3D pieza = new Transform3D();
        pieza.setTranslation(translation);
        //initialTransform
        TransformGroup tgRot = new TransformGroup(pieza);
        tgRot.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        tgRot.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        Transform3D initialTransform = new Transform3D();
        initialTransform.setTranslation(centro);
        TransformGroup tgOffset = new TransformGroup(initialTransform);
        TransformGroup tgModel = loadModel(modelPath);
        tgOffset.addChild(tgModel);
        tgRot.addChild(tgOffset);

        controllers.put(name, new TransformController(tgRot, translation));
        return tgRot;
    }

    private TransformGroup loadModel(String filePath) {
        ObjectFile loader = new ObjectFile(ObjectFile.RESIZE);
        BranchGroup group = new BranchGroup();
        Transform3D scaleTransform = new Transform3D();
        scaleTransform.setScale(0.2);  // Escala global
        
        Transform3D rotacion = new Transform3D();
        rotacion.rotZ(Math.PI); // Rotación de 180° en Z
        TransformGroup tgScaled;
        rotacion.setScale(0.2);
        if ("models/Garra2.obj".equals(filePath)) {
        tgScaled = new TransformGroup(rotacion);
        } 
        else {
        tgScaled = new TransformGroup(scaleTransform);
        }
        try {
            Scene scene = loader.load(new FileReader(filePath));
            tgScaled.addChild(scene.getSceneGroup());
            
        } catch (IncorrectFormatException | ParsingErrorException | FileNotFoundException e) {
            System.err.println("Error cargando modelo: " + filePath);
        }

        group.addChild(tgScaled);
        TransformGroup outer = new TransformGroup();
        
        outer.addChild(group);
        return outer;
    }

    private void addBaseControls(JPanel container) {
        JPanel panel = new JPanel(new GridLayout(1, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Base"));
        
        // Solo rotación en Y (giro horizontal)
        panel.add(createSlider("Base", "Y", -180, 180, "Rotación"));
        container.add(panel);
    }

    private void addArmControls(String partName, JPanel container) {
        JPanel panel = new JPanel(new GridLayout(2, 1));
        panel.setBorder(BorderFactory.createTitledBorder(partName));
        
        // Rotación en X (inclinación hacia adelante/atrás)
        panel.add(createSlider(partName, "X", -90, 90, "Inclinación"));
        
        container.add(panel);
    }

    private void addGripperControls(JPanel container) {
        JPanel panel = new JPanel(new GridLayout(2, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Pinza"));
        
        // Apertura/cierre de la pinza (ambas partes se mueven en X)
        panel.add(createSliderG("Garra1", "X", 0, 45, "Apertura"));
        //panel.add(createSlider("Garra2", "X", -45, 0, "Apertura"));
        
        container.add(panel);
    }

    private JPanel createSlider(String part, String axis, int min, int max, String label) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel lbl = new JLabel(label + ": 0°");
        JSlider slider = new JSlider(min, max, 0);
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(slider, BorderLayout.CENTER);

        slider.addChangeListener(e -> {
            int angle = slider.getValue();
            lbl.setText(label + ": " + angle + "°");
            controllers.get(part).setRotation(axis, angle);
        });

        return panel;
    }
    private JPanel createSliderG(String part, String axis, int min, int max, String label) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel lbl = new JLabel(label + ": 0°");
        JSlider slider = new JSlider(min, max, 0);
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(slider, BorderLayout.CENTER);

        slider.addChangeListener(e -> {
            int angle = slider.getValue();
            int angle2 = angle*-1;
            lbl.setText(label + ": " + angle + "°");
            controllers.get(part).setRotation(axis, angle+20);
            controllers.get("Garra2").setRotation(axis, angle2-20);
        });

        return panel;
    }

    public static void main(String[] args) {
        System.setProperty("sun.awt.noerasebackground","true");
        SwingUtilities.invokeLater(() -> {
            Brazorobotico app = new Brazorobotico();
            app.setVisible(true);
        });
    }

    private static class TransformController {
        private final TransformGroup tg;
        private final Vector3f position;
        private float rotX = 0, rotY = 0, rotZ = 0;

        public TransformController(TransformGroup tg, Vector3f position) {
            this.tg = tg;
            this.position = position;
        }

        public void setRotation(String axis, float degrees) {
            switch (axis) {
                case "X":
                    rotX = (float) Math.toRadians(degrees);
                    break;
                case "Y":
                    rotY = (float) Math.toRadians(degrees);
                    break;
                case "Z":
                    rotZ = (float) Math.toRadians(degrees);
                    break;
            }

            Transform3D rotXform = new Transform3D();
            Transform3D temp = new Transform3D();

            rotXform.rotX(rotX);
            temp.rotY(rotY);
            rotXform.mul(temp);
            temp.rotZ(rotZ);
            rotXform.mul(temp);

            rotXform.setTranslation(position);
            tg.setTransform(rotXform);
        }
    }
}